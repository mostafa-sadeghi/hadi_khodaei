def my_function():
    print("hello")