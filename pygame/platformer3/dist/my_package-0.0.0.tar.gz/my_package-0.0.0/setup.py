from setuptools import setup



setup(name="my_package",
      url="https://github.com/mostafa-sadeghi/hadi_khodaei.git",
      packages=['my_package']
      
      )