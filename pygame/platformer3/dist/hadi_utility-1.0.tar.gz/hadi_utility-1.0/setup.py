from setuptools import setup



setup(name="hadi_utility",
      version="1.0",
      description="this package is used for converting path",
      author="hadi",
      author_email="hadi@gmail.com",

      packages=['hadi_utility'],
      install_requires=['requests']
      
      )