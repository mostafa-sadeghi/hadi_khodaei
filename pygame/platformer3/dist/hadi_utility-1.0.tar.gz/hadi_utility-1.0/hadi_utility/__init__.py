from hadi_utility.path_handler import get_absolute_path

__all__ = ['get_absolute_path']