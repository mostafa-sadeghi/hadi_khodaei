def get_absolute_path():
    print("your path is here")